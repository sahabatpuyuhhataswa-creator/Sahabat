import React, { useState, useEffect } from 'react';
import { EggRecord } from '../types/quail';
import { formatRupiah } from '../utils/calculations';
import { X, Egg, Check, Save } from 'lucide-react';

interface EditEggModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: EggRecord | null;
  onSave: (record: EggRecord) => void;
}

export const EditEggModal: React.FC<EditEggModalProps> = ({
  isOpen,
  onClose,
  record,
  onSave,
}) => {
  const [date, setDate] = useState('');
  const [timeOfDay, setTimeOfDay] = useState<'Pagi' | 'Sore' | 'Total Hari'>('Total Hari');
  const [kandang, setKandang] = useState('');
  const [goodEggsPcs, setGoodEggsPcs] = useState(0);
  const [brokenEggsPcs, setBrokenEggsPcs] = useState(0);
  const [totalWeightKg, setTotalWeightKg] = useState(0);
  const [sellingPricePerKg, setSellingPricePerKg] = useState(33000);
  const [buyerName, setBuyerName] = useState('');
  const [paymentStatus, setPaymentStatus] = useState<'Lunas' | 'Piutang' | 'Stok Belum Terjual'>('Lunas');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (record) {
      setDate(record.date);
      setTimeOfDay(record.timeOfDay);
      setKandang(record.kandang);
      setGoodEggsPcs(record.goodEggsPcs);
      setBrokenEggsPcs(record.brokenEggsPcs);
      setTotalWeightKg(record.totalWeightKg);
      setSellingPricePerKg(record.sellingPricePerKg);
      setBuyerName(record.buyerName || '');
      setPaymentStatus(record.paymentStatus);
      setNotes(record.notes || '');
    }
  }, [record, isOpen]);

  if (!isOpen || !record) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const revenue = Math.round(Number(totalWeightKg) * Number(sellingPricePerKg));

    onSave({
      ...record,
      date,
      timeOfDay,
      kandang,
      goodEggsPcs: Number(goodEggsPcs),
      brokenEggsPcs: Number(brokenEggsPcs),
      totalWeightKg: Number(totalWeightKg),
      sellingPricePerKg: Number(sellingPricePerKg),
      revenue,
      buyerName: buyerName || undefined,
      paymentStatus,
      notes: notes || undefined,
    });
    onClose();
  };

  const calculatedRevenue = Math.round(Number(totalWeightKg) * Number(sellingPricePerKg));
  const totalPcs = Number(goodEggsPcs) + Number(brokenEggsPcs);
  const avgWeight = totalPcs > 0 ? ((Number(totalWeightKg) * 1000) / totalPcs).toFixed(1) : '0';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-scale-up my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-bold text-sm">
            <Egg className="w-5 h-5 text-amber-400" />
            <span>Edit Catatan Panen Telur</span>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs text-slate-700">
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 leading-relaxed">
            Perubahan data panen telur ini akan langsung disimpan permanen di perangkat Anda dan memperbarui metrik Hen Day (HDP %), total tonase panen, dan omzet keuangan.
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Tanggal Panen:
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Waktu Pengambilan:
              </label>
              <select
                value={timeOfDay}
                onChange={(e) => setTimeOfDay(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold"
              >
                <option value="Total Hari">Total Hari</option>
                <option value="Pagi">Pagi (07.00 - 09.00)</option>
                <option value="Sore">Sore (15.00 - 17.00)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">
              Kandang Asal:
            </label>
            <input
              type="text"
              required
              value={kandang}
              onChange={(e) => setKandang(e.target.value)}
              placeholder="misal: Kandang Petelur A, Blok B"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium"
            />
          </div>

          <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div>
              <label className="block text-[10px] font-semibold text-slate-700 mb-1">
                Butir Utuh:
              </label>
              <input
                type="number"
                min="0"
                required
                value={goodEggsPcs}
                onChange={(e) => setGoodEggsPcs(parseInt(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-rose-600 mb-1">
                Retak / Rusak:
              </label>
              <input
                type="number"
                min="0"
                value={brokenEggsPcs}
                onChange={(e) => setBrokenEggsPcs(parseInt(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-rose-600"
              />
            </div>
            <div>
              <label className="block text-[10px] font-semibold text-amber-700 mb-1">
                Total Berat (Kg):
              </label>
              <input
                type="number"
                min="0"
                step="0.1"
                required
                value={totalWeightKg}
                onChange={(e) => setTotalWeightKg(parseFloat(e.target.value) || 0)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
              />
            </div>
          </div>

          <div className="p-2.5 bg-slate-100 rounded-lg flex items-center justify-between text-[11px] text-slate-600">
            <span>Rata-rata Bobot Telur:</span>
            <span className="font-bold text-slate-800">{avgWeight} gram / butir</span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Harga Jual per Kg (Rp):
              </label>
              <input
                type="number"
                min="0"
                step="500"
                required
                value={sellingPricePerKg}
                onChange={(e) => setSellingPricePerKg(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Estimasi Omzet:
              </label>
              <div className="w-full px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-extrabold text-emerald-700 tabular-nums">
                {formatRupiah(calculatedRevenue)}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Nama Pembeli / Agen:
              </label>
              <input
                type="text"
                value={buyerName}
                onChange={(e) => setBuyerName(e.target.value)}
                placeholder="Pengepul Pasar Induk / Toko"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
              />
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                Status Pembayaran:
              </label>
              <select
                value={paymentStatus}
                onChange={(e) => setPaymentStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold"
              >
                <option value="Lunas">Lunas</option>
                <option value="Piutang">Piutang (Belum Bayar)</option>
                <option value="Stok Belum Terjual">Stok Belum Terjual</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">
              Catatan Panen:
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Kondisi cangkang tebal, cuaca mendung, dsb."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl transition"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Perubahan Panen</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
